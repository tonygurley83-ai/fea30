module.exports = {
  apps: [
    {
      name: "postgres",
      cwd: "/data/data/com.termux/files/home/downloads/fea/feaclient_server/FEAClientApiService",

      script: "server/postgres.sh",
      interpreter: "bash",

      autorestart: true,
      watch: false,

      out_file: "./logs/postgres-out.log",
      error_file: "./logs/postgres-error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",

      max_restarts: 20,
      min_uptime: "10s"
    },

    {
      name: "auth",
      cwd: "/data/data/com.termux/files/home/downloads/fea/feaclient_server/FEAClientApiService",

      script: "auth/auth-server.js",
      interpreter: "node",

      autorestart: true,
      watch: false,

      out_file: "./logs/auth-out.log",
      error_file: "./logs/auth-error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",

      max_restarts: 20,
      min_uptime: "10s"
    },

    {
      name: "frontend",
      cwd: "/data/data/com.termux/files/home/downloads/fea/feaclient_server",

      script: "npm",
      args: "start",
      interpreter: "none",

      autorestart: true,
      watch: false,

      out_file: "./logs/frontend-out.log",
      error_file: "./logs/frontend-error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",

      env: {
        NODE_ENV: "development"
      },

      max_restarts: 20,
      min_uptime: "10s"
    }
  ]
};

