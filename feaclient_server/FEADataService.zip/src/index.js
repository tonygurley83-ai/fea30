import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import CanvasManager from "../CanvasTools/CanvasManager";

var mountNode = document.getElementById("app");

ReactDOM.render(<App name="Finite Analyzer" />, mountNode);

var mountManager = document.getElementById("canvasmanager");

ReactDOM.render(<CanvasManager name="FA Manager"/>, mountManager);